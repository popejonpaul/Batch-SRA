import subprocess
from subprocess import CalledProcessError, PIPE
import pathlib
import multiprocessing
from multiprocessing import Process

def zippy(record):  # records = sra_ids
    print('Starting thread to zip ' + record + ' accessions.')
    command = ["gunzip", '-f', '/scrfs/storage/jappleseed/Fasta2/' + record]
    try:
        print('Executing command "' + ' '.join(command) + '"')
        subprocess.run(command, check=True, stderr=PIPE)  # run or call command? run
    except CalledProcessError as bad_proc:
        print('Failed to zip record ' + record + '.')
        print(bad_proc.stderr)

if (__name__ == '__main__'):
    targets = []
    sra_numbers = []
    pre_path = pathlib.Path('/scrfs/storage/jappleseed/Fasta2/')
    for item in pre_path.iterdir():
        sra_id = str(item.name)
        if '.gz' in sra_id:  # Script claims there is already a .gz exists added -f to command
            sra_numbers.append(sra_id)
        # if '.gz.gz' in sra_id:
            # print('Starting to unzip ' + sra_id + ' accessions.')
            # command = ["gunzip", '-f', '/scrfs/storage/jappleseed/Fasta2/' + sra_id]
            # try:
                # print('Executing command "' + ' '.join(command) + '"')
                # subprocess.run(command, check=True, stderr=PIPE)  # run or call command? run
            # except CalledProcessError as bad_proc:
                # print('Failed to zip record ' + sra_id + '.')
                # print(bad_proc.stderr)
                
    # for i in range(len(sra_numbers)):
        # zippy(sra_numbers[i])
 
    for i in range(32):
        targets.append([sra_numbers[j] for j in range(i, len(sra_numbers), 32)])
    for i in range(32):
        threads = []
        for j in range(32):
            threads.append(Process(target=zippy, args=[targets[j][i]]))
        for j in range(32):
            threads[j].start()
        for j in range(32):
            threads[j].join()