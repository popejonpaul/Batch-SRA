from multiprocessing import Pool
import numpy
import pandas
import pathlib
import shutil
import subprocess
import os
from subprocess import CalledProcessError, PIPE

n_workers = 32

def find_file_by_partial_name(directory, acc):
    for file_path in directory.iterdir():
        if(acc in str(file_path.stem)):
            return file_path
    return None

def check_membership_of_dir(directory, threshold, table, result = {'Filename' : [], 'Cluster' : [], 'Distance_to_Medoid' : []}):
    for item in directory.iterdir():
        sra_id = str(item.name)
        if '.gz' in sra_id:
            command = ["gunzip", '-f', '/scrfs/storage/jappleseed/Fasta2/' + sra_id]
            subprocess.run(command, check=True, stderr=PIPE)
    genomes = list(directory.iterdir())
    args = [(genomes[x], threshold, table) for x in range(len(genomes))]
    genomes = [str(x.stem) for x in genomes]

    with Pool(n_workers) as pool:
        something = pool.map(check_membership, args)
    clusters = [something[x][0] for x in range(len(something))]
    distances = [something[x][1] for x in range(len(something))]

    result['Filename'] = result['Filename'] + genomes
    result['Cluster'] = result['Cluster'] + clusters
    result['Distance_to_Medoid'] = result['Distance_to_Medoid'] + distances

    return result

def check_membership(args):
    filename, threshold, table = args

    distances = []

    for med in table.index:
        try:
            output = subprocess.run(['./mash-Linux64-v2.3/mash', 'dist', str(filename.absolute()), '/scrfs/storage/jappleseed/Template_Genomes/'+med+'.fna'], stdout=subprocess.PIPE, encoding='utf-8').stdout
            output = str(output)
        #print(output,flush=True)
            output = output.split('\t')
        #print(output,flush=True)
            print(output[2],flush=True)
            output = output[2]
            distance = float(output)
            distances.append(distance)
        except:
            pass
        
    if distances:    
        mindex = numpy.array(distances, dtype='float').argmin()
        mindist = distances[mindex]
        cluster = table['Cluster'][mindex]
        avg_dist = table['Average_Distance'][mindex]
        std_dist = table['STD_Distance'][mindex]

        threshold = threshold * std_dist + avg_dist
        if(mindist > threshold):
            cluster = -cluster
    
        return (cluster, mindist)
    else:#return filler
        return (float(100),float(100))
                        #create tmp and wrk dirs first
def inflate_dir(path, tmpdir=pathlib.Path('/scrfs/storage/jappleseed/temp'), dest=pathlib.Path('/scrfs/storage/jappleseed/wrk')):
    #for path in path.iterdir(): #not a directory error
    print('Processing ' + str(path.stem), flush=True)
    print('\tUnzipping', flush=True)
    subprocess.run(['gunzip', '-c', str(path.absolute()), '>', str(tmpdir.absolute())])#gunzip not unzip
    acc = str(path.stem)
    source = tmpdir / f'ncbi_dataset/data/{acc}'
    print('\tSearching ' + str(source), flush=True)
    try:
        source = find_file_by_partial_name(source.absolute(), acc)
        if(source is None):
            print('\tNot Found')
            print('\tCleaning Directory', flush=True)
            subprocess.run(['rm', '-rf', tmpdir.absolute()])
            tmpdir.mkdir()
            #continue
        print('\tFound', flush=True)
        d = dest / f'{acc}.fna'
        print('\tMoving File', flush=True)
        shutil.move(source.absolute(), d.absolute())
    except:
        print('\tFailed')
    print('\tSuccess')
    print('\tCleaning Directory', flush=True)
    subprocess.run(['rm', '-rf', tmpdir.absolute()])
    tmpdir.mkdir()

def clear_wrk_dir(dest=pathlib.Path('/scrfs/storage/jappleseed/wrk')):
    subprocess.run(['rm -rf ' + str(dest.absolute()) + '/*'], shell=True)

def member_dirwise(path, tmpdir=pathlib.Path('/scrfs/storage/jappleseed/temp'), workdir=pathlib.Path('/scrfs/storage/jappleseed/wrk')):
    table = pandas.read_csv('cluster_table.csv', index_col=1)
    result = None
    for p in path.iterdir():
        inflate_dir(p, tmpdir, workdir)
        if(result is None):
            result = check_membership_of_dir(workdir, 2, table)
        else:
            result = check_membership_of_dir(workdir, 2, table, result)
        clear_wrk_dir(workdir)
        
        pandas.DataFrame(result).to_csv('genbank_membership_Fasta.csv')#change file

if(__name__ == '__main__'):
    table = pandas.read_csv('cluster_table.csv', index_col=1)
    result=check_membership_of_dir(pathlib.Path('/scrfs/storage/jappleseed/Fasta2/'),2,table)
    workdir=pathlib.Path('/scrfs/storage/jappleseed/wrk')
    clear_wrk_dir(workdir)
    pandas.DataFrame(result).to_csv('genbank_membership_Fasta2.csv')
    print("end")
    #member_dirwise(pathlib.Path('/scrfs/storage/jappleseed/Fasta/'))
    #need to unzip dir using gunzip not unzip
    #need to utilize multithreading
